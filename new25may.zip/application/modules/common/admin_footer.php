    <script type="text/javascript">
    	$(".date").datepicker(
    		{
    			format: 'yyyy-mm-dd',
    			startDate: '+0d',
        		autoclose: true
    		}
    	);

    	var url = '<?php echo base_url();?>';
    </script>

</body>
</html>

