<?php 	
		$this->load->view("../../../../common/admin_header");
	  	$this->load->view('admin/common/admin_sidebar');
	  	$this->load->view("admin/".$body);
	  	$this->load->view("../../../../common/admin_footer");   
?>
