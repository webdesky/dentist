<?php $this->load->view("admin/common/admin_header");
	  $this->load->view('admin/common/admin_sidebar');   ?>
<?php $this->load->view("admin/".$body);  ?>
<?php $this->load->view("admin/common/admin_footer");   ?>
