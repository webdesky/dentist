    
    <script src="<?php echo base_url('asset/vendor/metisMenu/metisMenu.min.js');?>"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url('asset/dist/js/sb-admin-2.js');?>"></script>

</body>
</html>

